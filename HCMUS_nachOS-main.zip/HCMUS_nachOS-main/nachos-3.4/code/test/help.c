#include "syscall.h"

int main()
{
	PrintString("HELP\n");
	PrintString("- ascii program: this program will create the table of ascii\n");
	PrintString("- sort program: this program will sort the array of n integers with n being a number entered by the user\n");
	Halt();
}
