#include "syscall.h"

int main()
{
	int a;
	PrintString("Moi nhap so nguyen (4.123 = 4): ");
	a = ReadInt();

	PrintString("So nguyen da nhap: ");
	PrintInt(a);
	PrintString("\n");
	Halt();
}