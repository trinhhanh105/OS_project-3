

#include "syscall.h"

int main()
{
	char a;
	PrintString("Moi nhap ky tu: ");
	a = ReadChar();

	PrintString("Ky tu da nhap: ");
	PrintChar(a);
	PrintString("\n");
	Halt();
}
