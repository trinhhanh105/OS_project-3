#include "syscall.h"

int main()
{
	char* str;
	int maxLen;
	maxLen = 200;
	PrintString("Moi nhap chuoi: ");
	ReadString(str, maxLen);
	PrintString("Chuoi da nhap: ");
	PrintString(str);
	PrintString("\n");
	Halt();
}