#include "syscall.h"

int main()
{
	int n; 
	int arr[102];
	int i;
	int j; 
	int temp;	
	PrintString("Enter input numbers:\n");
	n = ReadInt();
	
	for (i=0;i<n;i++)
	{
		arr[i]=ReadInt();	
	}

	for (i=0;i<n-1;i++)
		for (j=i+1;j<n;j++)
		{
			if (arr[i]>arr[j])
			{
				temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;			
			}		
		}
	
	PrintString("Sorted array:\n");	
	for (i=0;i<n;i++)
	{
		PrintInt(arr[i]);
		PrintString(" ");	
	}
	Halt();
}
