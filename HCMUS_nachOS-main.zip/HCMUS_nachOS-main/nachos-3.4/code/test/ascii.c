#include "syscall.h"

int main()
{
	int i;
	PrintString("ASCII Table:\n");
	for (i = 0; i < 128; i++)
	{
		PrintInt(i);
		PrintChar(" ");
		PrintChar((char)i);
		PrintChar('\n');
	}
	Halt();
}
