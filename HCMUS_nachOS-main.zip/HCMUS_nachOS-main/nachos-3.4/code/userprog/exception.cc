// exception.cc 
//	Entry point into the Nachos kernel from user programs.
//	There are two kinds of things that can cause control to
//	transfer back to here from user code:
//
//	syscall -- The user code explicitly requests to call a procedure
//	in the Nachos kernel.  Right now, the only function we support is
//	"Halt".
//
//	exceptions -- The user code does something that the CPU can't handle.
//	For instance, accessing memory that doesn't exist, arithmetic errors,
//	etc.  
//
//	Interrupts (which can also cause control to transfer from user
//	code into the Nachos kernel) are handled elsewhere.
//
// For now, this only handles the Halt() system call.
// Everything else core dumps.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "system.h"
#include "syscall.h"

//----------------------------------------------------------------------
// ExceptionHandler
// 	Entry point into the Nachos kernel.  Called when a user program
//	is executing, and either does a syscall, or generates an addressing
//	or arithmetic exception.
//
// 	For system calls, the following is the calling convention:
//
// 	system call code -- r2
//		arg1 -- r4
//		arg2 -- r5
//		arg3 -- r6
//		arg4 -- r7
//
//	The result of the system call, if any, must be put back into r2. 
//
// And don't forget to increment the pc before returning. (Or else you'll
// loop making the same system call forever!
//
//	"which" is the kind of exception.  The list of possible exceptions 
//	are in machine.h.
//----------------------------------------------------------------------

void IncreaseProgramCounter() 
{
    int pcAfter = machine->ReadRegister(NextPCReg) + 4;
    machine->WriteRegister(PrevPCReg, machine->ReadRegister(PCReg));
    machine->WriteRegister(PCReg, machine->ReadRegister(NextPCReg));
    machine->WriteRegister(NextPCReg, pcAfter);
}

/*
Input: - User space address (int)
- Limit of buffer (int)
Output:- Buffer (char*)
Purpose: Copy buffer from User memory space to System memory space
*/
char* User2System(int virtAddr,int limit)
{
	int i;// index
	int oneChar;
	char* kernelBuf = NULL;
	kernelBuf = new char[limit +1];//need for terminal string
	if (kernelBuf == NULL)
		return kernelBuf;
	memset(kernelBuf,0,limit+1);
	//printf("\n Filename u2s:");
	
	for (i = 0 ; i < limit ;i++)
	{
		machine->ReadMem(virtAddr+i,1,&oneChar);
		kernelBuf[i] = (char)oneChar;
		//printf("%c",kernelBuf[i]);
		if (oneChar == 0)
			break;
	}
	return kernelBuf;
}
/*
Input: - User space address (int)
- Limit of buffer (int)
- Buffer (char[])
Output:- Number of bytes copied (int)
Purpose: Copy buffer from System memory space to User memory space
*/
int System2User(int virtAddr,int len,char* buffer)
{
	if (len < 0)
	{
		return -1;
	}
	if (len == 0)
	{
		return len;
	}

	int i = 0;
	int oneChar = 0 ;
	do{
		oneChar= (int) buffer[i];
		machine->WriteMem(virtAddr+i,1,oneChar);
		i ++;
	}while(i < len && oneChar != 0);
	return i;
}
/*void ReadCharImplement()
{
	int sz;
	sz = 255;
	char* tmp ;
	tmp= new char[sz + 1];
	int len;
	len = gSynchConsole->Read(tmp, sz);
	if (len < 0)
	{
		DEBUG('a', "\nCannot read character");
		machine->WriteRegister(2, 0);
		return;
	}
	machine->WriteRegister(2, (int)tmp);
	IncreaseProgramCounter();
	return ;
}
void PrintCharImplement(char character)
{
	gSynchConsole->Write(&character, 1);
	IncreaseProgramCounter();
}*/
int ReadInt()
{
	/*
		Input: None
		Output:- Number
		Purpose: read number which user imported
		*/
	char* input;
	int inputLength, numberLen, isNegative, number, i;

	inputLength = 100;
	input = new char[inputLength + 1];
	numberLen = gSynchConsole->Read(input, inputLength);

	isNegative = 0;
	number = 0;
	i = 0;

	if (input[i] == '-') //check if number is negative
	{
		isNegative = 1;
		i++;
	}

	while (i <= inputLength && input[i] >= '0' && input[i] <= '9')
	{
		number = number * 10 + (char)input[i] - '0'; //add 
		i++;
	}
	if (i <= inputLength && input[i] != '\0')
	{
		if (input[i] != '.')
		{
			number = 0;
		}
		else
		{
			i++;
			while (i <= inputLength && input[i] != '\0')
			{
				if (input[i] < '0' || input[i] > '9')
				{
					number = 0;
					break;
				}
				i++;
			}
		}
	}

	if (isNegative)
	{
		number = -number;
	}
	machine->WriteRegister(2, number);
	IncreaseProgramCounter();
	delete[] input;
	return number;
}
void PrintInt(int numberArg)
{
	int count, temp, len, index;
	
	char* output;
	len = 200;
	index = 0;
	output = new char[len + 1];
	if (numberArg < 0)
	{
		output[index] = '-';
		//gSynchConsole->Write("-", 1);
		numberArg = numberArg * -1;
		index++;
	}
	else if (numberArg == 0)
	{
		output[index] = '0';
		output[index + 1] = '\n';
		output[index + 2] = '\0';
		gSynchConsole->Write(output, index + 2);
		IncreaseProgramCounter();
		return;
	}

	count = 1;
	temp = numberArg / 10;
	while (temp > 0)
	{
		count = count * 10;
		temp /= 10;
	}

	while (count > 0 && index <= len)
	{
		int num;
		num = numberArg / count;
		numberArg = numberArg - num * count;
		output[index] = (char)num + '0';
		index++;
		count /= 10;
	}

	output[index] = '\0';
	gSynchConsole->Write(output, index);
	delete[] output;
	IncreaseProgramCounter();
}
void ReadString(char buffer[], int length)
{
	int bufferArrdress, realLenght;
	bufferArrdress = machine->ReadRegister(4);
	int temp;
	temp = gSynchConsole->Read(buffer, length);
	
	System2User(bufferArrdress, length, buffer);
	delete[] buffer;
	IncreaseProgramCounter();
}
void PrintString(char bufferNew[])
{
	int bufferAddr, maxLen, realLen;
	bufferAddr = machine->ReadRegister(4);

	maxLen = 200; 
	bufferNew = User2System(bufferAddr, maxLen);
	
	gSynchConsole->Write(bufferNew, maxLen);
	
	IncreaseProgramCounter();
}
char ReadChar()
{
	int sz;
	sz = 255;
	char* tmp;
	tmp = new char[sz + 1];
	int leng;
	leng = gSynchConsole->Read(tmp, sz);
	char ch;
	ch = tmp[0];
	if (leng < 0)
	{
		DEBUG('a', "\nCannot read character");
		machine->WriteRegister(2, 0);
		return ch;
	}
	

	machine->WriteRegister(2, (int)ch);
	IncreaseProgramCounter();
	return ch;
}
void PrintChar(char character)
{
	gSynchConsole->Write(&character, 1);
	IncreaseProgramCounter();
}

void ExceptionHandler(ExceptionType which)
{
    int type = machine->ReadRegister(2);
    switch(which)
    {
    case NoException:
		return;
    case SyscallException:
		switch(type)
		{
		    case SC_Halt:
				DEBUG('a', "\nShutdown, initiated by user program.\n");
				printf("\nShutdown, initiated by user program.\n");
		   		interrupt->Halt();
				break;	
		    case SC_ReadInt:
				ReadInt();
				break;

			case SC_PrintInt:
				int numberArg;
				numberArg = machine->ReadRegister(4);
				PrintInt(numberArg);
				break;		

			case SC_ReadString:
				int length;	
				char* buffer;
				length = machine->ReadRegister(5);
				buffer = new char[length + 1];
				ReadString(buffer, length);
				break;

			case SC_PrintString:
				char* bufferNew;
				
				PrintString(bufferNew);

				break;
			case SC_PrintChar:
				char c;
				c = (char)machine->ReadRegister(4);
				PrintChar(c);
				//c=c+32;
				
				break;
			case SC_ReadChar:
				ReadChar();
				break;
			
			
			default:
				DEBUG('a', "Unexpected user mode exception\n");
				printf("Unexpected user mode exception %d %d\n", which, type);
   				interrupt->Halt();
   				break;

		}
		break;

    case PageFaultException:
		DEBUG('a', "PageFaultException occurred\n");
		printf("PageFaultException occurred\n");
	   	interrupt->Halt();
		break;	
    case ReadOnlyException:
		DEBUG('a', "ReadOnlyException occurred\n");
		printf("ReadOnlyException occurred\n");
	   	interrupt->Halt();
		break;	
    case BusErrorException:
		DEBUG('a', "BusErrorException occurred\n");
		printf("BusErrorException occurred\n");
	   	interrupt->Halt();
		break;	
    case AddressErrorException:
		DEBUG('a', "AddressErrorException occurred\n");
		printf("AddressErrorException occurred\n");
	   	interrupt->Halt();
		break;	
    case OverflowException:
		DEBUG('a', "OverflowException occurred\n");
		printf("OverflowException occurred\n");
	   	interrupt->Halt();
		break;	
    case IllegalInstrException:
		DEBUG('a', "IllegalInstrException occurred\n");
		printf("IllegalInstrException occurred\n");
	   	interrupt->Halt();
		break;	
    case NumExceptionTypes:
		DEBUG('a', "NumExceptionTypes occurred\n");
		printf("NumExceptionTypes occurred\n");
	   	interrupt->Halt();
		break;	
	default:
		interrupt->Halt();
		break;
    }
/*
    if ((which == SyscallException) && (type == SC_Halt)) {
	DEBUG('a', "Shutdown, initiated by user program.\n");
   	interrupt->Halt();
    } else {
	printf("Unexpected user mode exception %d %d\n", which, type);
	ASSERT(FALSE);
    }
*/
}
